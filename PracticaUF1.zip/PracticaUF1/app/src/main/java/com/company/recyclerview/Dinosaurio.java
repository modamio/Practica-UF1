package com.company.recyclerview;

import android.widget.ImageView;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Dinosaurio {
    @PrimaryKey(autoGenerate = true)
    int id;
    String nombre;
    String descripcion;
    int foto;

    public Dinosaurio(String nombre, String descripcion, int foto) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.foto = foto;
    }
}

package com.company.recyclerview;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.company.recyclerview.databinding.FragmentMostrarDinosarioBinding;



public class MostrarDinosaurioFragment extends Fragment {
    private FragmentMostrarDinosarioBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentMostrarDinosarioBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        DinosauriosViewModel elementosViewModel = new ViewModelProvider(requireActivity()).get(DinosauriosViewModel.class);

        elementosViewModel.seleccionado().observe(getViewLifecycleOwner(), new Observer<Dinosaurio>() {
            @Override
            public void onChanged(Dinosaurio dinosaurio) {
                binding.nombre.setText(dinosaurio.nombre);
                binding.descripcion.setText(dinosaurio.descripcion);
                binding.foto.setImageResource(dinosaurio.foto);

            }
        });

        final CalculoViewModel calculoViewModel = new ViewModelProvider(this).get(CalculoViewModel.class);

        binding.calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double lvl = Double.parseDouble(binding.nivel.getText().toString());

                calculoViewModel.calcular(lvl);
            }
        });

        calculoViewModel.domesticado.observe(getViewLifecycleOwner(), new Observer<Double>() {
            @Override
            public void onChanged(Double lvl) {
                binding.domesticado.setText(String.format("Nivel base despues de el tameo " + "%.0f",lvl));
            }
        });

        calculoViewModel.errorLvl.observe(getViewLifecycleOwner(), new Observer<Double>() {
            @Override
            public void onChanged(Double lvlMinimo) {
                if (lvlMinimo != null) {
                    binding.nivel.setError(String.format("El nivel no puede ser inferor a " + "%.0f", lvlMinimo));
                } else {
                    binding.nivel.setError(null);
                }
            }
        });
    }
}
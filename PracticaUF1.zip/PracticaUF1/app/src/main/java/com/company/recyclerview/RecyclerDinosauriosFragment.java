package com.company.recyclerview;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.company.recyclerview.databinding.FragmentRecyclerDinosauriosBinding;
import com.company.recyclerview.databinding.ViewholderElementoBinding;

import java.util.List;


public class RecyclerDinosauriosFragment extends Fragment {

    private FragmentRecyclerDinosauriosBinding binding;
    private DinosauriosViewModel dinosauriosViewModel;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentRecyclerDinosauriosBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dinosauriosViewModel = new ViewModelProvider(requireActivity()).get(DinosauriosViewModel.class);
        navController = Navigation.findNavController(view);

        binding.irANuevoElemento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.action_recyclerElementosFragment_to_nuevoElementoFragment);
            }
        });
        DinosauriosAdapter elementosAdapter = new DinosauriosAdapter();
        binding.recyclerView.setAdapter(elementosAdapter);
        dinosauriosViewModel.obtener().observe(getViewLifecycleOwner(), new Observer<List<Dinosaurio>>() {
            @Override
            public void onChanged(List<Dinosaurio> dinosaurios) {
                elementosAdapter.establecerLista(dinosaurios);
            }
        });
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN,
                ItemTouchHelper.RIGHT  | ItemTouchHelper.LEFT) {

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int posicion = viewHolder.getAdapterPosition();
                Dinosaurio dinosaurio = elementosAdapter.obtenerDinosaurio(posicion);
                dinosauriosViewModel.eliminar(dinosaurio);

            }
        }).attachToRecyclerView(binding.recyclerView);

    }
    class DinosaurioViewHolder extends RecyclerView.ViewHolder {
        private final ViewholderElementoBinding binding;

        public DinosaurioViewHolder(ViewholderElementoBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
    class DinosauriosAdapter extends RecyclerView.Adapter<DinosaurioViewHolder> {

        List<Dinosaurio> dinosaurios;

        @NonNull
        @Override
        public DinosaurioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new DinosaurioViewHolder(ViewholderElementoBinding.inflate(getLayoutInflater(), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull DinosaurioViewHolder holder, int position) {

            Dinosaurio dinosaurio = dinosaurios.get(position);

            holder.binding.nombre.setText(dinosaurio.nombre);
            holder.binding.foto.setImageResource(dinosaurio.foto);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dinosauriosViewModel.seleccionar(dinosaurio);
                    navController.navigate(R.id.action_recyclerElementosFragment_to_mostrarElementoFragment);
                }
            });
        }

        @Override
        public int getItemCount() {
            return dinosaurios != null ? dinosaurios.size() : 0;
        }

        public void establecerLista(List<Dinosaurio> elementos){
            this.dinosaurios = elementos;
            notifyDataSetChanged();
        }
        public Dinosaurio obtenerDinosaurio(int posicion){
            return dinosaurios.get(posicion);
        }

    }
}
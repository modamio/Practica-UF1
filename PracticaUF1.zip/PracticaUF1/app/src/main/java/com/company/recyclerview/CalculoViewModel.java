package com.company.recyclerview;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class CalculoViewModel extends AndroidViewModel {
    Executor executor;
    SimuladorCalculadora simulador;
    MutableLiveData<Double> domesticado = new MutableLiveData<>();
    MutableLiveData<Double> errorLvl = new MutableLiveData<>();

    public CalculoViewModel(@NonNull Application application) {
        super(application);

        executor = Executors.newSingleThreadExecutor();
        simulador = new SimuladorCalculadora();

    }

    public void calcular(double lvl) {

        final SimuladorCalculadora.Solicitud solicitud = new SimuladorCalculadora.Solicitud(lvl);

        executor.execute(new Runnable() {
            @Override
            public void run() {
                simulador.calcular(solicitud, new SimuladorCalculadora.Callback() {
                    @Override
                    public void cuandoEsteCalculadoElLevel(double lvl) {
                        errorLvl.postValue(null);
                        domesticado.postValue(lvl);
                    }
                    @Override
                    public void cuandoElNivelSeaInferiorAUno(double lvlMinimo) {
                        errorLvl.postValue(lvlMinimo);
                    }
                });
            }
        });
    }
}

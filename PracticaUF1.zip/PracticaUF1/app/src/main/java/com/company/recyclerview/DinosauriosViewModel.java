package com.company.recyclerview;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

public class DinosauriosViewModel extends AndroidViewModel {

    DinosauriosRepositorio dinosauriosRepositorio;

    MutableLiveData<Dinosaurio> dinosaurioSeleccionado = new MutableLiveData<>();

    public DinosauriosViewModel(@NonNull Application application) {
        super(application);

        dinosauriosRepositorio = new DinosauriosRepositorio(application);


    }

    LiveData<List<Dinosaurio>> obtener(){
        return dinosauriosRepositorio.obtener();
    }
    void insertar(Dinosaurio dinosaurio){
        dinosauriosRepositorio.insertar(dinosaurio);
    }

    void eliminar(Dinosaurio dinosaurio){
        dinosauriosRepositorio.eliminar(dinosaurio);
    }
    void seleccionar(Dinosaurio dinosaurio){
        dinosaurioSeleccionado.setValue(dinosaurio);
    }

    MutableLiveData<Dinosaurio> seleccionado(){
        return dinosaurioSeleccionado;
    }


}

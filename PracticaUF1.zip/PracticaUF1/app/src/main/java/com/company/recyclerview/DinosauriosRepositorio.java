package com.company.recyclerview;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class DinosauriosRepositorio {
    DinosauriosBaseDeDatos.DinosauriosDao dinosauriosDao;
    Executor executor = Executors.newSingleThreadExecutor();

    DinosauriosRepositorio(Application application){
        dinosauriosDao = DinosauriosBaseDeDatos.obtenerInstancia(application).obtenerElementosDao();
    }




    LiveData<List<Dinosaurio>> obtener(){
        return dinosauriosDao.obtener();
    }

    void insertar(Dinosaurio dinosaurio){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                dinosauriosDao.insertar(dinosaurio);
            }
        });
    }

    void eliminar(Dinosaurio dinosaurio) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                dinosauriosDao.eliminar(dinosaurio);
            }
        });
    }



}

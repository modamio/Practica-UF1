package com.company.recyclerview;

public class SimuladorCalculadora {
    public static class Solicitud {
        public double lvl;


        public Solicitud(double lvl) {
            this.lvl = lvl;

        }
    }

    interface Callback {
        void cuandoEsteCalculadoElLevel(double lvl);
        void cuandoElNivelSeaInferiorAUno(double lvlMinimo);
    }

    public void calcular(Solicitud solicitud, Callback callback) {
        double cadaLvl = 1.5;
        double lvlMinimo = 1;

        boolean error = false;
        if (solicitud.lvl < lvlMinimo){
            callback.cuandoElNivelSeaInferiorAUno(lvlMinimo);
            error = true;
        }
        if (!error){
            callback.cuandoEsteCalculadoElLevel(solicitud.lvl*cadaLvl);

        }
    }
}

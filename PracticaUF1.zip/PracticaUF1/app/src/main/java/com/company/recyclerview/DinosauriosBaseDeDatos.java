package com.company.recyclerview;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Database;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.Update;

import java.util.List;

@Database(entities = {Dinosaurio.class}, version = 1, exportSchema = false)
public abstract class DinosauriosBaseDeDatos extends RoomDatabase {

    private static volatile DinosauriosBaseDeDatos INSTANCIA;


    static DinosauriosBaseDeDatos obtenerInstancia(final Context context) {
        if (INSTANCIA == null) {
            synchronized (DinosauriosBaseDeDatos.class) {
                if (INSTANCIA == null) {
                    INSTANCIA = Room.databaseBuilder(context,
                                    DinosauriosBaseDeDatos.class, "elementos.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCIA;
    }
    public abstract DinosauriosDao obtenerElementosDao();
    @Dao
    interface DinosauriosDao {
        @Query("SELECT * FROM Dinosaurio")
        LiveData<List<Dinosaurio>> obtener();

        @Insert
        void insertar(Dinosaurio dinosaurio);

        @Delete
        void eliminar(Dinosaurio dinosaurio);
    }
}
